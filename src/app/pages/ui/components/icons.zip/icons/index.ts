export * from './icons.component';
